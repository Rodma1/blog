---
name: 提交一个Bug
about: 告诉我们一个你遇到的bug以解决它
title: ''
labels: ''
assignees: ''

---

请按照本模板编写issues

**描述**
请详细的描述你所遇到的bug

**出现bug的页面**
页面链接：

**重现**
请重现你遇到bug的过程
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**截图**
如果方便的话，在这里添加截图来更清晰的说明你遇到的bug。

**桌面设备 (please complete the following information):**
 - 操作系统: [e.g. iOS]
 - 浏览器 [e.g. chrome, safari]
 - 版本 [e.g. 22]

**移动设备 (please complete the following information):**
 - 型号: [e.g. iPhone6]
 - 操作系统: [e.g. iOS8.1]
 - 浏览器 [e.g. stock browser, safari]
 - 版本 [e.g. 22]

**其他内容**
在此处添加其他信息
