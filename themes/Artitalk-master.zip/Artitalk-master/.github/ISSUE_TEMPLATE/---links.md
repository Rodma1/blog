---
name: 成功案例申请
about: 将你使用artitalk的站点放在文档中供大家查看效果
title: ''
labels: ''
assignees: ''

---

请按照以下格式给出
```
| /*博主昵称*/  | [/*使用本js的页面标题*/](/*使用本js的页面链接*/) |/*博客框架*/ | [/*所用主题名称*/](/*主题GitHub地址*/)   |


例如：
| Uncle_drew  | [说说](https://cndrew.cn/shuoshuo/) | Hexo | [Sakura](https://github.com/honjun/hexo-theme-sakura)   |
```
